const ORDER_ACCEPTED = 'accepted';
const ORDER_DELIVERED = 'delivered';
const EXCHANGE = 'orders';
const QUEUE = 'order.process';

module.exports = {
    ORDER_ACCEPTED: ORDER_ACCEPTED,
    ORDER_DELIVERED: ORDER_DELIVERED,
    EXCHANGE: EXCHANGE,
    QUEUE: QUEUE
}